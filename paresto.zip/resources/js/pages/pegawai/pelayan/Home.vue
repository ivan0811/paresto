<template>
    <div>
        Pelayan
    </div>
</template>
<script>
export default {

}
</script>
